# TAREA 1 INF221 2026-2

## Estructura del Repositorio

Este repositorio contiene la documentación, el código fuente y las instrucciones necesarias para la realización de la Tarea 1 de la asignatura *INF221 Algoritmos y Complejidad*.

A continuación, se describe la estructura del repositorio:

```bash
├── assignment_statement
├── code
├── report
└── README.md
```

### `assignment_statement`
Contiene el enunciado de la tarea, así como los archivos fuente del enunciado en formato LaTeX (.tex).

### `code`
Contiene la plantilla de los archivos que deberán estar presentes en la entrega de la tarea. En ella, se deben implementar los algoritmos solicitados, los cuales se detallan a continuación:
- `matrix_multiplication`: Algoritmo de Strassen y versión Naive.
- `sorting`: std::sort, merge sort, quick sort, patience sort.

### `report`
En esta carpeta se encuentra la plantilla en LaTeX para la elaboración del mini-informe correspondiente a la tarea.

